// Finding sum of all elements 
class ArraySum{
	int X[] = {1,2,3,4,5,6,7,8,9};
	int sum = 0;
	void elementSum(){
		for (int i=0; i<X.length; i++) {
			sum = sum+X[i];		
		}
		System.out.println("sum of elements : "+ sum);
     
	}
}
class Main{
	public static void main(String[] args) {
		ArraySum a = new ArraySum();
		a.elementSum();
	}
}