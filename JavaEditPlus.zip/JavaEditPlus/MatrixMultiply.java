class MatrixMultiply{
	void disp(){
		int A[][]= {{1,0,0},{0,1,0},{0,0,1}};
		int B[][]= {{1,2,3},{4,5,6},{7,8,9}};
		int C[][]= new int[3][3];
		for (int i=0; i<A.length; i++) {
			for (int j=0; j<A[i].length; j++) {
				C[i][j]=0;
				for (int k=0; k<A[i].length; k++) {
					C[i][j]= C[i][j]+A[i][k]*B[k][j];
				}
			}
			for (int n=0; n<A[i].length; n++) {
				System.out.println("MatrixMultiply element is : "+C[i][n]);
			}
		System.out.println("\n");	
		}
	}
}
class Main{
	public static void main(String[] args) {
		MatrixMultiply a=new MatrixMultiply();
		a.disp();
	}
}