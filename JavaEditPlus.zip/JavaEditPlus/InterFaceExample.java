interface I{
	 int x= 10;  // public static final
	 void m1(); //  abstract public
	 void m2(); // abstract and public  
}

class B implements I{
	public void m1(){
		System.out.println("m1 of I");
	}
	public void m2(){
		System.out.println("m2 of I");
	}
	public void m3(){
		System.out.println("m3 of B");
	}
}

class Main{
	public static void main(String[] args){
		I i = new B();  // creating reference variable of Interface and object of sub class
		i.m1();
		i.m2();
		//i.m3(); // givind error  
		System.out.println();
		B b = new B(); // creating reference variable of subclass and object is also sub class
		b.m1();
		b.m2();
		b.m3();
		System.out.println();
		// we can access inerface variable by 4 ways here.
		System.out.println(i.x); // by interface refrence variable 
		System.out.println(I.x); // by interface name  
		System.out.println(b.x); // by implentation class refe variable 
		System.out.println(B.x); // by implentation class name 

	}

}