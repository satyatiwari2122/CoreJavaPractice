class Test{
	static int max(int x, int y){
		x++;
		System.out.println(x);
		if(x>y){
			return x;
		}
		else{
			return y;
		}
	}
	public static void main(String[] args) {
		int a=10, b=15, c;
		System.out.println(a);
		c= max(a,b);
		System.out.println(c);
	}
}