class A{
	static{
		System.out.println("A-SB");
	}
	public static int m1(){
		System.out.println("A-m1");
		return 10;
	}
	static int i=m1();
	public static void main(String[] args) {
		
	}
}