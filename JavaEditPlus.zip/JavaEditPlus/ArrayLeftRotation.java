// Finding sum of all elements
class ArrayLeftRotation{
	int X[] = {1,2,3,4,5,6,7,8,9};
	int temp =X[0];
	void leftRotation(){
		for (int i=1; i<X.length; i++) {
			X[i-1]=X[i];	
		}
		X[X.length-1]=temp;
		System.out.println("Roatation after :");
		for(int x:X){
			System.out.println("elements are : "+x);
		}	     
	}
}
class Main{
	public static void main(String[] args) {
		ArrayLeftRotation a = new ArrayLeftRotation();
		a.leftRotation();
	}
}