// Finding sum of all elements
class ArrayInsert{
	int X[] = new int[10];
	int n=6;
	int index=2;
	void insertElement(){
		X[0]=5;
	    X[1]=6;
	    X[2]=7;
	    X[3]=8;
	    X[4]=9;
	    X[5]=10;
		System.out.println("Before delete :");
		for(int x:X){
			System.out.println("elements are : "+x);
		}	
		for (int i=index; i<n; i++) {
			X[i]=X[i+1];	
		}
		System.out.println("Insertion after :");
		for(int x:X){
			System.out.println("elements are : "+x);
		}	     
	}
}
class Main{
	public static void main(String[] args) {
		ArrayInsert a = new ArrayInsert();
		a.insertElement();
	}
}