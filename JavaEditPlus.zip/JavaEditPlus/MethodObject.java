class Test{
	static void update(int A[]){
		A[0]=10;
	}
	static String getUserName(String email){
		int a=email.indexOf('@');
		String name= email.substring(0,a);
		return name;
	}
	public static void main(String[] args) {
		int A[]= new int[5];
        String email="satya@gmail.com";
        String uname=getUserName(email);
        System.out.println(uname);
		update(A);
		System.out.println(A[0]);
	}
}