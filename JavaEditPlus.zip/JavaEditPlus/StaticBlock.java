class A{
	int i=10;
	static int j=20;
	static{
		A a= new A();
		System.out.println("Int i");
		System.out.println("Int j");
	}
	public static void main(String[] args) {
		
	}
}


class Test{
	public static void main(String[] args) {
		
	}
}