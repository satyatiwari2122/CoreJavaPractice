class Student 
{
	int rollno=100;
	String name ="Satya";
	float fees = 200.10f;
	String add="Delhi"; 
	public void getStudentDetails(){
		System.out.println("Student details are as follows :");
		System.out.println("------------------------------------");
		System.out.println("Student Rollno is :   "+ rollno);
		System.out.println("Student Rollno is :   "+ name);
		System.out.println("Student Rollno is :   "+ fees);
		System.out.println("Student Rollno is :   "+ add);
	}
}
public class Main
{
	public static void main(String[] args){
		Student stu = new Student();
		stu.getStudentDetails();
	}
}