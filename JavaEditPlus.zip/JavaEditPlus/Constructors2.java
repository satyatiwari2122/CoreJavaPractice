class ConstructorsNeed{
	String acc_No;
	String acc_Name;
	int acc_Balance;
	// Zero arguments Constructors
	ConstructorsNeed(){
		acc_No= "1000";
		acc_Name= "Savings";
		acc_Balance= 3217735;
	}
	public void getAccountsDetails(){
		System.out.println("Account NO : "+acc_No);
		System.out.println("Account acc_Name : "+acc_Name);
		System.out.println("Account acc_Balance : "+acc_Balance);
	}
}

class Test{
	public static void main(String[] args) {
		ConstructorsNeed ac1= new ConstructorsNeed();
		ac1.getAccountsDetails();
		ConstructorsNeed ac2= new ConstructorsNeed();
		ac2.getAccountsDetails();
	}
}