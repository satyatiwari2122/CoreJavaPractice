// Finding sum of all elements
class ArraySearchLargest{
	int X[] = {1,2,3,4,5,6,7,8,9};
	int max =X[0];
	void elementSearchLargest(){

		for (int i=0; i<X.length; i++) {
			if (X[i]>max){
				max=X[i];
			}

		}
		System.out.println("Largest elements is: "+ max);	     
	}
}
class Main{
	public static void main(String[] args) {
		ArraySearchLargest a = new ArraySearchLargest();
		a.elementSearchLargest();
	}
}