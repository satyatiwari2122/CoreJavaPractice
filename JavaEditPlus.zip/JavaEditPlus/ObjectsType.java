class ObjectTypes{
	public static void main(String[] args) {
		String s1=new String("Durga");
		String s2= s1.concat("Software");
		String s3= s2.concat("Solutions");
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);

		StringBuffer sb1= new StringBuffer("Durga");
		System.out.println("before append"+sb1);
		StringBuffer sb2= sb1.append("Software");
		StringBuffer sb3= sb2.append("Solutions");
		System.out.println(sb1);
		System.out.println(sb2);
		System.out.println(sb3);

	}
}