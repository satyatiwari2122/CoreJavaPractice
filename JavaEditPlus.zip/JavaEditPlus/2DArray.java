class DArray{
	void display(){
		int A[][]= new int[4][5];
		int B[][]= {{1,2,3},{4,5,6},{7,8,9}};
		int C[][];
		C= new int[3][3];
		for (int i=0;i<B.length; i++) {
			for (int j=0; j<B[0].length; j++) {
				System.out.println("For loop Element is : "+B[i][j]);
			}
		System.out.println("\n");
		}
		for (int x[] : B) {
			for (int y : x) {
				System.out.println("For each Element is : "+y);
			}
		System.out.println("\n");	
		}
		int D[][];
		D= new int[3][];
		D[0]= new int[3];
		D[1]= new int[2];
		D[2]= new int[4];
	}

}
class Main{
	public static void main(String[] args) {
		DArray a=new DArray();
		a.display();
	}
}
