// Finding sum of all elements
class ArrayCopy{
	int A[]= {1,2,3,4,5};
	int B[] = new int[10];
	void copyElement(){
		for (int i=0; i<A.length; i++) {
			B[i]=A[i];	
		}
		System.out.println("elements of A :");
		for(int x:A){
			System.out.println("elements is : "+x);
		}
		System.out.println("elements of B :");
		for(int x:B){
			System.out.println("elements are : "+x);
		}	     
	}
}
class Main{
	public static void main(String[] args) {
		ArrayCopy a = new ArrayCopy();
		a.copyElement();
	}
}