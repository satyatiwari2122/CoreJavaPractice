class ConstructorsNeed{
	String acc_No;
	String acc_Name;
	int acc_Balance;
	ConstructorsNeed(String ano, String aname, int abal){
		acc_No= ano;
		acc_Name= aname;
		acc_Balance= abal;
	}
	public void getAccountsDetails(){
		System.out.println("Account NO : "+acc_No);
		System.out.println("Account acc_Name : "+acc_Name);
		System.out.println("Account acc_Balance : "+acc_Balance);
	}
}

class Test{
	public static void main(String[] args) {
		ConstructorsNeed ac1= new ConstructorsNeed("12345", "First", 10000);
		ac1.getAccountsDetails();
		ConstructorsNeed ac2= new ConstructorsNeed("237321", "Second", 20000);
		ac2.getAccountsDetails();
	}
}