// Finding sum of all elements
class Array2SearchLargest{
	int X[] = {1,2,3,4,5,6,7,8,9};
	int max1, max2 =X[0];
	void element2SearchLargest(){

		for (int i=0; i<X.length; i++) {
			if (X[i]>max1){
				max2=max1;
				max1=X[i];
			}
			else if (X[i]>max2) {
				max2=X[i];
			}

		}
		System.out.println("Second Largest elements is: "+ max2);	     
	}
}
class Main{
	public static void main(String[] args) {
		Array2SearchLargest a = new Array2SearchLargest();
		a.element2SearchLargest();
	}
}