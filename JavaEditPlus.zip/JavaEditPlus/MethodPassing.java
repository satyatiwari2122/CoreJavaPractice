class Test{
	// finding prime number
	static boolean isPrime(int n){
		for (int i=2; i<n/2; i++) {
			if (n%i==0){
				return false;
			}
		}
		return true;
	}
	// find GCD or HCF
	static int getGcd(int m, int n){
		while(m!=n){
			if (m>n) {
				m=m-n;
			}
			else{
				n=n-m;
			}
		}
		return m;
	}
	// find max element of the array
	static int getMax(int A[]){
		int max=A[0];
		for (int i=1; i<A.length; i++) {
			if (max<A[i]) {
				max=A[i];
			}
		}
		return max;
	}

	public static void main(String[] args) {
		int A[]= {1,4,45,100,0,2};
		System.out.println("Number is prime ? "+isPrime(31));
		System.out.println("GCD of the numbers is : "+getGcd(25,15));
		System.out.println("Max element of the array is : "+getMax(A));
	}
}