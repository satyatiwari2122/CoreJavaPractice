// Finding sum of all elements
import java.util.Scanner;
import java.io.*;
class ArraySearch{
	int X[] = {1,2,3,4,5,6,7,8,9};
	boolean found= false;
	void elementSearch(){
		Scanner sc = new Scanner(System.in);
	    System.out.println("Enter a number to search: ");
	    int key= sc.nextInt();

		for (int i=0; i<X.length; i++) {
			if (key==X[i]){
				found= true;
				System.out.println("elements found at index : "+i);
			}

		}
		if(found==false){
			System.out.println("elements not found");
		}	     
	}
}
class Main{
	public static void main(String[] args) {
		ArraySearch a = new ArraySearch();
		a.elementSearch();
	}
}