abstract class A{
 void m1(){
 	System.out.println("m1 of A");
 }
 abstract void m2();
 abstract void m3();
}

class B extends A{
	void m2(){
		System.out.println("m2 of B");
	}
	void m3(){
		System.out.println("m3 of B");
	}
	void m4(){
		System.out.println("m4 of B");
	}
}

class Main{
	public static void main(String[] args){
		A a = new B();  // creating reference variable of abstarct class and object of sub class
		a.m1();
		a.m2();
		a.m3();
		//a.m4();  givind error 
		System.out.println();
		B b = new B(); // creating reference variable of subclass and object is also sub class
		b.m1();
		b.m2();
		b.m3();
		b.m4();
	}

}