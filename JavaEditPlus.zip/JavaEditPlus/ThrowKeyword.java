class Student{
	int sid;
	String sname;
	float smarks;
	String status="";
	Student(int sid, String sname, float smarks){
		this.sid=sid;
		this.sname=sname;
		this.smarks=smarks;
	}
	public void getStudentDetails(){
		if(smarks>=0 && smarks<=500){
			if (smarks<=100) {
				status ="Fail";
			}
			else if (smarks>=300 && smarks<400) {
				status= "Grade B";
			}
			else{
				status= "Grade A";
			}

		}
		else{
			throw new RuntimeException("Marks out of bound exception");
		}
		System.out.println("Students details are as follows");
		System.out.println("--------------------------------");
		System.out.println("Students id is : "+this.sid);
		System.out.println("Students name is : "+this.sname);
		System.out.println("Students marks is : "+this.smarks);
		System.out.println("Students staus : "+this.status);
	}
}

class Test{
	public static void main(String[] args) {
		Student s1= new Student(100, "HHH", 50);
		s1.getStudentDetails();
		Student s2= new Student(200, "GGG", 350);
		s2.getStudentDetails();
		Student s3= new Student(300, "CCC", 450);
		s3.getStudentDetails();
		Student s4= new Student(400, "III", 1450);
		s4.getStudentDetails();
	}
}