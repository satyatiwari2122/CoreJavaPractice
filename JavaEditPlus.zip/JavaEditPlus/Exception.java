class Test{
	public static void main(String[] args) {
		System.out.println("A-class byte code Loaded");
		int a[]={1,2,3,4};
		System.out.println(a[5]);
		//A a1=new A();
		//A a2=new A();
	}
}