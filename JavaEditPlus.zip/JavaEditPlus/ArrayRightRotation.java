// Finding sum of all elements
class ArrayRightRotation{
	int X[] = {1,2,3,4,5,6,7,8,9};
	int temp =X[X.length-1];
	void rightRotation(){
		System.out.println("Roatation before :");
		for(int x:X){
			System.out.println("elements are : "+x);
		}	
		for (int i=X.length-2; i>=0; i--) {
			X[X.length-1]=X[i];	
		}
		X[0]=temp;
		System.out.println("Roatation after :");
		for(int x:X){
			System.out.println("elements are : "+x);
		}	     
	}
}
class Main{
	public static void main(String[] args) {
		ArrayRightRotation a = new ArrayRightRotation();
		a.rightRotation();
	}
}