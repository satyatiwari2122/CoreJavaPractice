

import java.io.*;
class Test{
	public static void main(String[] args) throws Exception{
		FileReader fr= new FileReader("D:/JavaFiles/abc.txt");
		String data = "";
		int val= fr.read();
		while (val != -1) {
			data = data + (char) val;
			val = fr.read();
		}
		fr.close();
		FileWriter fw= new FileWriter("D:/JavaFiles/satya.txt");
		char[] ch = data.toCharArray();
		fw.write(ch);
		System.out.println("file Copied");
		fw.close();
	}
}