class MyThread extends Thread{
	public static void main(String[] args) {
		MyThread t= new MyThread();
		System.out.println(t);
	}
}