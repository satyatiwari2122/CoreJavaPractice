
import java.io.*;
import java.util.*;
class Test{
	public static void main(String[] args){
			Console c = System.console();
			String uname = c.readLine("Enter UserName : ");
			char[] pwd = c.readPassword("Enter password : ");
			String pass = new String(pwd);
			if (uname.equals("Satya") && pass.equals("Tiwari")) {
				System.out.println("Login Success");
			}
			else{
				System.out.println("Login Failure");
			}
		}
	}