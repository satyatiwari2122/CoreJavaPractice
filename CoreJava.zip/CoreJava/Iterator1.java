import java.util.*;
class Iterator1{
	public static void main(String[] args) {
		Vector <String> v= new Vector <String>();
		v.add("A");
		v.add("B");
		v.add("C");
		v.add("D");
		v.add("E");
		Iterator <String> vi = v.iterator();

		while(vi.hasNext()){
			System.out.println(vi.next());
		}

		System.out.println();

		Set <Integer> s= new HashSet<Integer>();
		s.add(10);
		s.add(20);
		s.add(30);
		s.add(40);
		s.add(50);
		System.out.println();
		Iterator <Integer> si = s.iterator();
		while(si.hasNext()){
			System.out.println(si.next());
		}
		System.out.println();

		Queue <Float> q= new PriorityQueue<Float>();
		q.add(1f);
		q.add(2f);
		q.add(3f);
		q.add(4f);
		q.add(5f);
		Iterator <Float>qi = q.iterator();
		while(qi.hasNext()){
			System.out.println(qi.next());
		}
		System.out.println();

		List <String> list=new ArrayList <String>();

		list.add("AAAA");
		list.add("BBBB");
		list.add("CCCC");
		list.add("DDDD");
		list.add("EEEE");
		System.out.println(list);
		Iterator <String> li = list.iterator();
		while(li.hasNext()){
			System.out.println(li.next());
			//String element= li.next();
		    //if (element.equals("CCCC")) {
			//li.remove();
     		//}
		}
		//System.out.println();
		//System.out.println(list);
	}
}