import java.util.*;
import java.lang.*;

class Students{
	String sid;
	String sname;
	int smarks;
	String sadd;
	// Constructors
	Students(String sid, String sname, int smarks, String sadd){
		this.sid=sid;
		this.sname=sname;
		this.smarks=smarks;
		this.sadd=sadd;
	}
	@Override
	public String toString(){
		return "Students sid :"+sid+" sname: "+sname+" smarks: "+smarks+" sadd: "+sadd +"\n";
	}
}

class MyComparator implements Comparator <Students>{
	public int compare(Students stu1, Students stu2){
		//int val= stu1.sname.compareTo(stu2.sname);
		return stu1.smarks- stu2.smarks;
	}
}

class Test{
	public static void main(String[] args) {
		Students s1= new Students("101", "AAA", 345, "Delhi");
		Students s2= new Students("102", "BB", 445, "Noida");
		Students s3= new Students("103", "CCCCC", 245, "Ranchi");
		Students s4= new Students("104", "D", 145, "Lucknow");
		Students s5= new Students("105", "EEEEEEE", 545, "Gonda");

		MyComparator mc =new MyComparator();
		TreeSet <Students> ts = new TreeSet <Students>(mc);
		ts.add(s2); 
		ts.add(s1); 
		ts.add(s3); 
		ts.add(s5); 
		ts.add(s4); 
		System.out.println(ts);
	}
}