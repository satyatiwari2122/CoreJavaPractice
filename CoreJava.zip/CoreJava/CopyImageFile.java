// DeadLock problem 

import java.io.*;
class Test{
	public static void main(String[] args) throws Exception{
		FileInputStream fis = new FileInputStream("D:/JavaFiles/ram1.jpg");
		int size = fis.available();
		byte[] b= new byte[size];
		fis.read(b);
		FileOutputStream fo = new FileOutputStream("D:/JavaFiles/ram12.jpg");
		fo.write(b);
		System.out.println("Iamge copied");
	}
}