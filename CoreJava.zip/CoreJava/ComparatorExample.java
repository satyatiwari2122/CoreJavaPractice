import java.util.*;
import java.lang.*;

class MyComparator implements Comparator <StringBuffer>{
	public int compare(StringBuffer stringBuff1, StringBuffer stringBuff2){
		/*int length1 = strinBuff1.length();
		int length2 = stringBuff2.length();
		int val = 0;
		if (length1<length2) {
		 	val = -100;
		} else if (length1>length2) {
		 	val = 100;
		}else{
		 	val = 0;
		}
		return val;*/
		return -(stringBuff1.length()-stringBuff2.length());
	}
}

class Test{
	public static void main(String[] args) {
		StringBuffer sb1= new StringBuffer("AAA");
		StringBuffer sb2= new StringBuffer("BBBBB");
		StringBuffer sb3= new StringBuffer("C");
		StringBuffer sb4= new StringBuffer("DDDD");
		StringBuffer sb5= new StringBuffer("EE");

		MyComparator mc =new MyComparator();
		TreeSet <StringBuffer> ts = new TreeSet <StringBuffer>(mc);
		ts.add(sb2); 
		ts.add(sb1); 
		ts.add(sb3); 
		ts.add(sb5); 
		ts.add(sb4); 
		System.out.println(ts);
	}
}