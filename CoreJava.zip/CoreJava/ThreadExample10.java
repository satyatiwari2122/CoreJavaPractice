class Aam{
	void dispaly(){
		for (int i=0; i<10; i++) {
			System.out.print(Thread.currentThread().getName()+"  ");
		}
	}
}

class MyThread extends Thread{
	Aam a;
	MyThread(Aam a){
		this.a=a;
	}
	public void run(){
		a.dispaly();
	}
}


class Test{
	public static void main(String[] args) {
		Aam a= new Aam();
		MyThread m1= new MyThread(a);
		MyThread m2= new MyThread(a); 
		MyThread m3= new MyThread(a);
		m1.setName("MyThread1"); 
		m2.setName("MyThread2"); 
		m3.setName("MyThread3");
		m1.start();
		m2.start();
		m3.start();
	}
}