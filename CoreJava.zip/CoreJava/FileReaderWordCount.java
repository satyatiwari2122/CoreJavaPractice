import java.io.*;
class Test{
	public static void main(String[] args) throws Exception{
		String filename = args[0];
		FileReader fr = new FileReader(filename);
		String data = "";
		int val = fr.read();
		while(val != -1){
			data = data + (char)val;
			val= fr.read();
		}
		String [] totalWords = data.split(" ");
		System.out.println("Total words count : "+ totalWords.length);
		int count = 0;
		for (String x : totalWords) {
			if(x.equals("satya")){
				count = count +1;
			}
		}
		System.out.println("Total Repeated words delhi is : "+ count);
	}
}