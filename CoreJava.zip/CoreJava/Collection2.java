import java.util.*;
class Collection2{
	public static void main(String[] args) {
		Vector <String> v= new Vector <String>();
		v.add("A");
		v.add("B");
		v.add("C");
		v.add("D");
		v.add("E");
		Enumeration e = v.elements();

		while(e.hasMoreElements()){
			System.out.println(e.nextElement());
		}

		System.out.println(v);
	}
}