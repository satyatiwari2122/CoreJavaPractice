class MyThread extends Thread{
	public void run(){
		for (int i=0; i<10; i++) {
			System.out.println("MyThread "+ i);
		}
	}
}


class Test{
	public static void main(String[] args) throws Exception{
		MyThread m1= new MyThread();
		m1.start();
		//m1.join();
		for (int i=0; i<10; i++) {
			System.out.println("Main Thread "+ i);
		}
	}
}