
import java.io.*;
import java.util.*;
class Test{
	public static void main(String[] args){
		try(
			Scanner sc = new Scanner(System.in);
			){
			System.out.println("Employee details : ");
			System.out.println();
			System.out.print("Enter Employee Number: ");
			int empNo = sc.nextInt();
			System.out.print("Enter Employee name: ");
			String empName = sc.next();
			System.out.print("Enter Employee Salary: ");
			float empSal = sc.nextFloat();
			sc.nextLine();
			System.out.print("Enter Employee address: ");
			String empAdd = sc.nextLine();
			System.out.println("==============================");
			System.out.println("Employee number: "+empNo);
			System.out.println("Employee name: "+empName);
			System.out.println("Employee Salary: "+empSal);
			System.out.println("Employee address: "+empAdd);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}