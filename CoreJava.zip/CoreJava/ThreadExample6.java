// Thread class methods setName() and getName()
class MyThread{
	public static void main(String[] args) {
		Thread t= new Thread();
		System.out.println(t.getPriority());
		t.setPriority(Thread.MAX_PRIORITY-2);
		System.out.println(t.getPriority());
	}
}