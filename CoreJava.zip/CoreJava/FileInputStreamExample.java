// DeadLock problem 

import java.io.*;
class Test{
	public static void main(String[] args) throws Exception{
		String filename = args[0];
		FileInputStream fis = new FileInputStream(filename);
		int size = fis.available();
		byte[] b= new byte[size];
		fis.read(b);
		String data = new String(b);
		System.out.println(data);
	}
}