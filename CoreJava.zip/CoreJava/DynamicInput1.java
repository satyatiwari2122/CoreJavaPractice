
import java.io.*;
//import java.util.*;
class Test{
	public static void main(String[] args){
		try(
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			){
			System.out.println("Employee details : ");
			System.out.println();
			System.out.print("Enter Employee Number: ");
			int empNo = Integer.parseInt(br.readLine());
			System.out.print("Enter Employee name: ");
			String empName = br.readLine();
			System.out.print("Enter Employee Salary: ");
			float empSal = Float.parseFloat(br.readLine());
			System.out.print("Enter Employee address: ");
			String empAdd = br.readLine();
			System.out.println("==============================");
			System.out.println("Employee number: "+empNo);
			System.out.println("Employee name: "+empName);
			System.out.println("Employee Salary: "+empSal);
			System.out.println("Employee address: "+empAdd);
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}