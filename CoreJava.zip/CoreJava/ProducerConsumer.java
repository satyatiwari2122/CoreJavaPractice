// Producer and consumer problem 

class Product{
	boolean flag=true;
	int itemCount=0;
	public synchronized void produce(){
		try{
			while(true){
				if (flag == true) {
					itemCount= itemCount+1;
					System.out.println("Item produce: "+ itemCount);
					flag =false;
					notify();
					wait();
				}else{
					wait();
				}
			}
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
	public synchronized void consume(){
		try{
			while(true){
				if (flag==true) {
					wait();
				}else{
					System.out.println("Item Consume :"+ itemCount);
					flag = true;
					notify();
					wait();
				}
			}

		}catch(Exception e){
			e.printStackTrace();
		}
	} 
}

class Producer extends Thread{
	Product d;
	public Producer(Product d){
		this.d=d;
	}
	public void run(){
		d.produce();
	}
}

class Consumer extends Thread{
	Product d;
	public Consumer(Product d){
		this.d=d;
	}
	public void run(){
		d.consume();
	}
}

class Test{
	public static void main(String[] args) {
		Product d = new Product();
		Producer p = new Producer(d);
		Consumer c = new Consumer(d);
		p.setName("Producer Thread");
		c.setName("Consumer Thread");
		p.start();
		c.start();
	}
}