// DeadLock problem 

import java.io.FileOutputStream;
class Test{
	public static void main(String[] args) throws Exception{
		FileOutputStream fos = new FileOutputStream("D:/JavaFiles/abc.txt",true);
		String data = "\t Welcome to delhi!";
		byte[] b = data.getBytes();
		fos.write(b);
		System.out.println("Data transfered");
		fos.close();
	}
}