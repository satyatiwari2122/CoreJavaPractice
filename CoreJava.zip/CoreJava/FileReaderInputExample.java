// DeadLock problem 

import java.io.*;
class Test{
	public static void main(String[] args) throws Exception{
		String filename = args[0];
		FileReader fr = new FileReader(filename);
		String data = "";
		int val = fr.read();
		while(val != -1){
			data = data + (char)val;
			val= fr.read();
		}
		System.out.println(data);
	}
}