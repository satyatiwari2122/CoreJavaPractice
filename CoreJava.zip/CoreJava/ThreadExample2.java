class MyThread extends Thread{
	public static void main(String[] args) {
		Thread t= new Thread("Core Java");
		System.out.println(t);
	}
}