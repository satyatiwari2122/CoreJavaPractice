class Aam{
	void dispaly(){
		for (int i=0; i<10; i++) {
			System.out.print(Thread.currentThread().getName()+"  ");
		}
	}
}

class MyThread1 extends Thread{
	Aam a;
	MyThread1(Aam a){
		this.a=a;
	}
	public void run(){
		a.dispaly();
	}
}

class MyThread2 extends Thread{
	Aam a;
	MyThread2(Aam a){
		this.a=a;
	}
	public void run(){
		a.dispaly();
	}
}

class MyThread3 extends Thread{
	Aam a;
	MyThread3(Aam a){
		this.a=a;
	}
	public void run(){
		a.dispaly();
	}
}
class Test{
	public static void main(String[] args) {
		Aam a= new Aam();
		MyThread1 m1= new MyThread1(a);
		MyThread2 m2= new MyThread2(a); 
		MyThread3 m3= new MyThread3(a);
		m1.setName("MyThread1"); 
		m2.setName("MyThread2"); 
		m3.setName("MyThread3");
		m1.start();
		m2.start();
		m3.start();
	}
}