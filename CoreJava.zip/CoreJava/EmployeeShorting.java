import java.util.*;
import java.lang.*;

class Employee{
	String eid;
	String ename;
	float esal;
	String eaddr;
	public Employee(String eid, String ename, float esal, String eaddr){
		this.eid = eid;
		this.ename = ename;
		this.esal = esal;
		this.eaddr = eaddr;
	}
	public String toString(){
		return "eid: "+eid+" ename: "+ ename +" esal: "+esal+" eaddr: "+eaddr+"\n";
	}
}

class MyComparator implements Comparator <Employee>{
		@Override
		public int compare(Employee e1, Employee e2){
			int val = 0;
			if (Test.sortingKey.equalsIgnoreCase("EID")) {
				val= e1.eid.compareTo(e2.eid);
			}
			if (Test.sortingKey.equalsIgnoreCase("ENAME")) {
				val= e1.ename.compareTo(e2.ename);
			}
			if (Test.sortingKey.equalsIgnoreCase("ESAL")) {
				val= (int)(e1.esal - e2.esal);
			}
			if (Test.sortingKey.equalsIgnoreCase("EADDR")) {
				val= e1.eaddr.compareTo(e2.eaddr);
			}
			if (Test.sortingOrder.equalsIgnoreCase("ASC")) {
				return val;
			}
			else{
				return -val;
			}
		}
} 

class Test{
	static String sortingKey = "";
	static String sortingOrder = "";
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int option =0;
		MyComparator myComp = new MyComparator();
		Employee emp1 = new Employee("E-111", "AAA", 100, "qdelhi1");
		Employee emp2 = new Employee("E-222", "BBB", 200, "adelhi2");
		Employee emp3 = new Employee("E-333", "CCC", 300, "felhi3");
		Employee emp4 = new Employee("E-444", "DDD", 400, "telhi4");
		Employee emp5 = new Employee("E-555", "EEE", 500, "eelhi5");
		System.out.println("Employee shorting application");
		System.out.println("==============================");
		while(true){
			System.out.println();
			System.out.println("1. Sorting by EID");
			System.out.println("2. Sorting by ENAME");
			System.out.println("3. Sorting by ESAL");
			System.out.println("4. Sorting by EADDR");
			System.out.println("5. EXIT");
			System.out.println("Enter Your Option : ");
			option = scanner.nextInt();
			if (option>0 && option<=4) {
				System.out.println("Shorting order[ASC/DESC] : ");
				sortingOrder = scanner.next();
			}
			switch(option){
				case 1:
				sortingKey = "EID";
				break;
				case 2:
				sortingKey = "ENAME";
				break;
				case 3:
				sortingKey = "ESAL";
				break;
				case 4:
				sortingKey = "EADDR";
				break;
				case 5:
				System.out.println("*************Thanku*********");
				System.exit(0);
				break;
				default :
				System.out.println("Invalid Option please enter 1,2,3,4,5");
			}
		    TreeSet<Employee> ts = new TreeSet<Employee>(myComp);
			ts.add(emp3);
			ts.add(emp1);
			ts.add(emp2);
			ts.add(emp5);
			ts.add(emp4);
			System.out.println(ts);
		}
	}
}