class MyThread{
	public static void main(String[] args) {
		Runnable r= new Thread();// Thread[Thread-0,5,main]
		System.out.println(r);
		Thread t= new Thread(r);
		System.out.println(t); // Thread[Thread-1,5,main]
	}
}