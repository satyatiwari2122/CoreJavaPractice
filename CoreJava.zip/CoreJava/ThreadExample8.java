// Thread class methods setName() and getName()
class MyThread{
	public static void main(String[] args) {
		Thread t1= new Thread();
		t1.start();
		for (int i=0; i<100; i++) {
			System.out.print(t1.isAlive()+"  ");
		}
	}
}