// Thread class methods setName() and getName()
class MyThread{
	public static void main(String[] args) {
		Thread t= new Thread();
		System.out.println(t); // Thread[Thread-0,5,main]
		System.out.println(t.getName()); //Thread-0
		t.setName("Core Java");
		System.out.println(t.getName());
	}
}