

import java.io.*;
class Test{
	public static void main(String[] args){
		try(
			FileReader fr= new FileReader("D:/JavaFiles/abc.txt");
			FileWriter fw= new FileWriter("D:/JavaFiles/super.txt");
			){
			String data = "";
			int val= fr.read();
			while (val != -1) {
				data = data + (char) val;
				val = fr.read();
			}
			char[] ch = data.toCharArray();
			fw.write(ch);
			System.out.println("file Copied");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
	}
}