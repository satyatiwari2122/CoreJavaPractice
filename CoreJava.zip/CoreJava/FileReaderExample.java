// DeadLock problem 

import java.io.FileReader;
class Test{
	public static void main(String[] args) throws Exception{
		FileReader fr = new FileReader("D:/JavaFiles/abc.txt");
		String data = "";
		int val = fr.read();
		while (val!= -1) {
			data = data +(char)val;
			val = fr.read();
		}
		System.out.println(data);
		fr.close();
	}
}