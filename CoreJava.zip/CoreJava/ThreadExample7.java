// Thread class methods setName() and getName()
class MyThread{
	public static void main(String[] args) {
		System.out.println(Thread.activeCount());
		Thread t1= new Thread();
		t1.start();
		System.out.println(Thread.activeCount());// <=2
		Thread t2= new Thread();
		t2.start();
		System.out.println(Thread.activeCount());// <=3
		Thread t3= new Thread();
		t3.start();
		System.out.println(Thread.activeCount());// <=4
	}
}