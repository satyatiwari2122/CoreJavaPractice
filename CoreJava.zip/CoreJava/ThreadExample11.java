class Aam{
	void dispaly(){
		for (int i=0; i<10; i++) {
			try{
				Thread.sleep(100);
			}catch(InterruptedException e){
  				e.printStackTrace();
			}
			System.out.println("Welome To Delhi");
		}
	}
}

class MyThread extends Thread{
	Aam a;
	MyThread(Aam a){
		this.a=a;
	}
	public void run(){
		a.dispaly();
	}
}


class Test{
	public static void main(String[] args) {
		Aam a= new Aam();
		MyThread m1= new MyThread(a);
		
		m1.start();
	}
}