// Sunchronized method

class Display{
	public void display(){
        System.out.println("Before synchronized block "+Thread.currentThread().getName());
		synchronized(this){
			for (int i= 1; i<6 ; i++) {
		 	System.out.println("Inside synchronized block "+Thread.currentThread().getName());
			}
		}		
	}
}

class DisplayThread extends Thread{
	Display d;
	public DisplayThread(Display d){
		this.d=d;
	}
	public void run(){
		d.display();
	}
}

class Test{
	public static void main(String[] args) {
		Display d= new Display();
		DisplayThread t1= new DisplayThread(d);
		DisplayThread t2= new DisplayThread(d);
		DisplayThread t3= new DisplayThread(d);
		t1.setName("T1 Thread");
		t2.setName("T2 Thread");
		t3.setName("T3 Thread");
		t1.start();
		t2.start();
		t3.start();
	}
}