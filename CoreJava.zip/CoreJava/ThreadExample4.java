class ThreadExample implements Runnable{
	public void run(){
		for (int i=0; i<10; i++) {
			System.out.println("ThreadExample : "+i);
		}

	}
}

class MyThread{
	public static void main(String[] args) {
		//ThreadExample mt= new ThreadExample();
		Runnable r = new ThreadExample();
		Thread t= new Thread(r);
		t.start();
		for (int i=0; i<10; i++) {
			System.out.println("Main Thread : "+i);
		}



		//Runnable r= new Thread();// Thread[Thread-0,5,main]
		//System.out.println(r);
		//Thread t= new Thread(r);
		//System.out.println(t); // Thread[Thread-1,5,main]
	}
}