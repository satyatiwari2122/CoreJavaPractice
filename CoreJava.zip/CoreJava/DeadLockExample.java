// DeadLock problem 

class RegisterCourse extends Thread{
	Object courseName;
	Object trainerName;
	public RegisterCourse(Object courseName, Object trainerName){
		this.courseName=courseName;
		this.trainerName=trainerName;
	}
	public void run(){
		synchronized(courseName){
			System.out.println("RegisterCourse holds courseName and waiting for trainerName");
			synchronized(trainerName){
				System.out.println("Get both resources and registration complete");
			}
		}
		
	}
}

class CancelCourse extends Thread{
	Object courseName;
	Object trainerName;
	public CancelCourse(Object courseName, Object trainerName){
		this.courseName=courseName;
		this.trainerName=trainerName;
	}
	public void run(){
		synchronized(trainerName){
			System.out.println("CancelCourse holds trainerName and waiting for courseName");
			synchronized(courseName){
				System.out.println("Get both resources and cancel complete");
			}
		}
	}
}


class Test{
	public static void main(String[] args) {
		Object registerCourse=new Object();
		Object cancelCourse= new Object();
		CancelCourse cc =new CancelCourse(registerCourse, cancelCourse);
		RegisterCourse rc =new RegisterCourse(registerCourse, cancelCourse);
		rc.start();
		cc.start();
	}
}