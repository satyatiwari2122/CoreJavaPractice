import java.util.*;
class ListIterator1{
	public static void main(String[] args) {
		

		List <String> list=new ArrayList <String>();

		list.add("AAAA");
		list.add("BBBB");
		list.add("CCCC");
		list.add("DDDD");
		list.add("EEEE");
		System.out.println(list);
		ListIterator <String> li = list.listIterator();
		System.out.println("Elements in forword directions : ");
		while(li.hasNext()){
			System.out.println(li.nextIndex()+" ---------> "+li.next());
		}
		System.out.println();
		System.out.println("Elements in backword directions : ");
		while(li.hasPrevious()){
			System.out.println(li.previousIndex()+" --------> "+li.previous());
		}

		// Perform some manipulation on the list

		LinkedList <String> ll= new LinkedList <String>();
		ll.add("A");
		ll.add("B");
		ll.add("C");
		ll.add("D");
		ll.add("E");
		System.out.println(ll);

		ListIterator <String> lli= ll.listIterator();
		while(lli.hasNext()){
			String elements = lli.next();
			if(elements.equals("B")){
				lli.add("X");
			}
			else if (elements.equals("D")){
				lli.set("y");
			}
			else if (elements.equals("E")){
				lli.remove();
			}
		}
		System.out.println(ll);
	}
}